# Solarized Dark Syntax theme

Atom theme using the ever popular dark [solarized](http://ethanschoonover.com/solarized) colors.

<img alt="screenshot" src="https://cloud.githubusercontent.com/assets/378023/12602908/9c252b08-c4f0-11e5-8833-6aad91b8fa34.png" srcset="https://cloud.githubusercontent.com/assets/378023/12602909/9c25b366-c4f0-11e5-9f5d-aa6a517f7d7e.png 2x">

This theme is installed by default with Atom and can be activated by going to
the _Themes_ section in the Settings view (`cmd-,`) and selecting it from the
_Syntax Themes_ dropdown menu.
